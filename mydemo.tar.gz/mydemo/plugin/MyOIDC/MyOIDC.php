<?php

require_once $global['systemRootPath'] . 'plugin/Plugin.abstract.php';

class MyOIDC extends PluginAbstract {

    public function getTags() {
        return array(
            PluginTags::$LOGIN,
        );
    }

    public function getDescription() {
        global $global;
        $obj = $this->getLogin();
        $name = $obj[0]->type;
        $str = "Login with OIDC Connect Integration";
        $str .= "<br>Valid OAuth redirect URIs: <strong>{$global['webSiteRootURL']}objects/login.json.php?type=$name</strong>";
        return $str;
    }

    public function getName() {
        return "MyOIDC";
    }

    public function getUUID() {
	/* Any unique string */
        return "oidc-8c31-4f15-a355-48715fac13f3";
    }

    public function getPluginVersion() {
        return "1.0";
    }

    public function getEmptyDataObject() {
        global $global;
        $obj = new stdClass();
        $obj->id = "";
        $obj->key = "";
        return $obj;	    
    }

    /**
     * Get Loggin Info
     *
     * @return array
     */
    public function getLogin() {

        global $global;
        $objWP = AVideoPlugin::getDataObject('MyOIDC');

        $logins = array();
        $obj = new stdClass();
        $obj->type = "MyOIDC";

	$logins[] = $obj;
        return $logins;
    }

}
