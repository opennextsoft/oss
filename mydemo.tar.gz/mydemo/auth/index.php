<?php

if (isset($_SERVER['OIDC_CLAIM_name'])) { 
    header("Location: http://tube.yourdomain.com/AVideo/login?type=MyOIDC&redirectUri=http://tube.yourdomain.com/AVideo/");
    exit;
} else { 
    header('HTTP/1.0 403 Forbidden');
    print('Forbidden!');
    exit;
}

?>
